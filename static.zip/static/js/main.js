/*! HANI main.js — site-wide (no-op on .coding-page-v2) */
  document.addEventListener('DOMContentLoaded', function () {
      // --- Global Flash Message to SweetAlert2 Handler ---
      const flashContainer = document.querySelector('#flash-messages-container .flash-messages-wrapper');
      if (flashContainer) {
          const alertDiv = flashContainer.querySelector('.alert');
          if (alertDiv) {
              const message = alertDiv.textContent.trim();
              let icon = 'info';
              let title = 'توجه!';

              if (alertDiv.classList.contains('alert-success')) {
                  icon = 'success';
                  title = 'موفق!';
              } else if (alertDiv.classList.contains('alert-danger')) {
                  icon = 'error';
                  title = 'خطا!';
              } else if (alertDiv.classList.contains('alert-info')) {
                  icon = 'info';
                  title = 'اطلاع‌رسانی';
              }

              // Use a short timer for success/info messages for better UX
              const timer = (icon === 'success' || icon === 'info') ? 1800 : null;

              Swal.fire({
                  title: title,
                  text: message,
                  icon: icon,
                  timer: timer,
                  showConfirmButton: !timer, // Show button only if there's no timer
                  confirmButtonText: 'متوجه شدم'
              });

              // Hide the original flash message container
              flashContainer.style.display = 'none';
          }
      }
  });
  
(function() {
  if (document.querySelector('.coding-page-v2')) {
    console.debug('[main.js] coding-page-v2 → skip legacy logic.');
    return;
  }
document.addEventListener('DOMContentLoaded', () => {
  /* ===== Scroll-to-Top (مشترک) ===== */
  const scrollToTopBtn = document.getElementById('scrollToTopBtn');
  if (scrollToTopBtn) {
    window.addEventListener('scroll', () => {
      const show = document.body.scrollTop > 100 || document.documentElement.scrollTop > 100;
      scrollToTopBtn.style.display = show ? 'block' : 'none';
    }, { passive: true });
    scrollToTopBtn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  }

  /* ===== اگر صفحه V2 نیست، کاری نکنیم (تا به صفحات قدیمی آسیب نزنیم) 
   * نکته: هر منطق عمومی باید خارج از صفحه V2 باشد؛
   *  - از دستکاری فرم ساخت کد جدید خودداری شود.
   *  - فقط اسکرول‌تو‌تاپ، دیت‌پیکرها، چارت‌ها، و موارد سراسری قدیمی.
   */

  // === راه‌انداز دیت‌پیکر (نمونه‌ی عمومی – فقط اگر المنت‌ها وجود دارند) ===
  if (window.$ && $('.persian-date-input').length) {
    try {
      $('.persian-date-input').persianDatepicker?.({
        format: 'YYYY/MM/DD',
        initialValue: false,
      });
    } catch (e) {
      console.warn('date picker init failed', e);
    }
  }

  // === مثال: چارت‌ها اگر روی صفحه‌ای وجود داشته باشند ===
  if (window.Chart && document.getElementById('dashboardChart')) {
    try {
      const ctx = document.getElementById('dashboardChart').getContext('2d');
      new Chart(ctx, {
        type: 'line',
        data: {
          labels: (window.dashboardLabels || []),
          datasets: [{
            label: 'نمونه',
            data: (window.dashboardData || []),
          }]
        },
        options: { responsive: true, maintainAspectRatio: false }
      });
    } catch (e) { console.warn('chart init failed', e); }
  }

  // === هر منطق عمومی/قدیمی دیگر مخصوص صفحات غیر V2 اینجاست ===
  // ...

  // ——— موارد مخصوص فرم قدیمی (اگر جایی غیر از V2 استفاده می‌شود) ———
  // (دقت کن کلاس‌ها/آیدی‌های V2 را دستکاری نکنیم)

  // انتخاب لایه ۱ قدیمی
  const layer1 = document.getElementById('layer_1');
  const dynamicStepsContainer = document.getElementById('dynamic-steps');
  const submitButton = document.getElementById('submit-btn-tour');

  const selections = {}; // ۱..۶
  function updateLivePreview() {
    const codeSpan = document.getElementById('live-code');
    const descSpan = document.getElementById('live-description');
    const codes = [];
    const descs = [];
    for (let i = 1; i <= 6; i++) {
      if (selections[i]?.code) codes.push(selections[i].code);
      if (selections[i]?.description) descs.push(selections[i].description);
    }
    const l7 = document.getElementById('layer_7_text');
    const tail = (l7?.value || '').trim();
    if (tail) descs.push(tail);
    if (codeSpan) codeSpan.textContent = codes.join('-');
    if (descSpan) descSpan.textContent = descs.join(' / ');
  }

  function getLayerName(level) {
    const map = {1:'کلاس',2:'گروه',3:'زیرگروه',4:'مدل',5:'ویژگی فنی',6:'ویژگی ظاهری',7:'شرح نهایی'};
    return map[level] || `لایه ${level}`;
  }

  function clearDownstream(fromLevel) {
    if (!dynamicStepsContainer) return;
    for (let L = fromLevel + 1; L <= 6; L++) {
      delete selections[L];
      const old = document.getElementById(`step-${L}`);
      if (old) old.remove();
    }
    const step7 = document.getElementById('step-7');
    if (step7) step7.style.display = 'none';
    submitButton && (submitButton.style.display = 'none');
    updateLivePreview();
  }

  async function createNextStep(level, parentId) {
    if (!dynamicStepsContainer) return;
    try {
      const resp = await fetch(`/api/get_children/${parentId}`, { headers: { Accept: 'application/json' } });
      if (!resp.ok) throw new Error('خطا در دریافت آیتم‌ها');
      const items = (await resp.json()) || [];
      if (!Array.isArray(items) || items.length === 0) return;

      const stepDiv = document.createElement('div');
      stepDiv.className = 'form-step';
      stepDiv.id = `step-${level}`;
      stepDiv.dataset.step = String(level);

      const label = document.createElement('label');
      label.htmlFor = `layer_${level}`;
      label.textContent = `لایه ${level}: ${getLayerName(level)}`;

      const group = document.createElement('div');
      group.className = 'input-group';

      const sel = document.createElement('select');
      sel.name = `layer_${level}`;
      sel.id = `layer_${level}`;
      sel.dataset.level = level;
      sel.required = true;
      sel.className = 'layer-select';
      sel.add(new Option(`یک ${getLayerName(level)} انتخاب کنید...`, ''));
      items.forEach(it => sel.add(new Option(`${it.description} (${it.code})`, it.id)));
      group.appendChild(sel);

      const userRole = (document.body.dataset.role || 'guest').toLowerCase();
      if (userRole === 'admin') {
        const addBtn = document.createElement('button');
        addBtn.type = 'button';
        addBtn.className = 'btn btn-add';
        addBtn.dataset.level = String(level);
        addBtn.dataset.parentId = String(parentId);
        addBtn.innerHTML = `<span>${getLayerName(level)} جدید</span>`;
        group.appendChild(addBtn);
      }

      stepDiv.appendChild(label);
      stepDiv.appendChild(group);
      dynamicStepsContainer.appendChild(stepDiv);

      document.dispatchEvent(new CustomEvent('stepRendered', { detail: { elementId: stepDiv.id } }));
    } catch (err) {
      console.error('createNextStep failed', err);
      try { Swal?.fire('خطا', 'دریافت آیتم‌ها انجام نشد.', 'error'); } catch (_) {}
    }
  }

  document.addEventListener('change', async (e) => {
    const select = e.target.closest && e.target.closest('select.layer-select');
    if (!select) return;
    const level = Number(select.dataset.level);
    const selectedId = select.value;

    let code = '', description = '';
    if (selectedId) {
      const opt = select.options[select.selectedIndex];
      const m = opt.text.match(/\((\d+)\)/);
      code = m?.[1] || '';
      description = (m ? opt.text.slice(0, m.index) : opt.text).trim();
    }
    selections[level] = { id: selectedId, code, description };

    clearDownstream(level - 1);
    if (!selectedId) { updateLivePreview(); return; }

    if (level < 6) {
      await createNextStep(level + 1, selectedId);
    } else {
      const step7 = document.getElementById('step-7'); if (step7) step7.style.display = '';
      submitButton && (submitButton.style.display = '');
    }
    updateLivePreview();
  });

  // کپی کد
  document.getElementById('copyLiveCode')?.addEventListener('click', () => {
    const t = document.getElementById('live-code')?.textContent || '';
    if (!t) return;
    navigator.clipboard?.writeText(t).then(() => {
      try { Swal?.fire({ toast:true, position:'bottom-start', timer:1400, showConfirmButton:false, icon:'success', title:'کد کپی شد' }); } catch(_){}
    });
  });

  // تایپ لایه ۷
  document.getElementById('layer_7_text')?.addEventListener('input', () => updateLivePreview());

  // تمرکز بعد از رندر هر مرحله
  document.addEventListener('stepRendered', (e) => {
    const el = document.getElementById(e.detail.elementId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      el.querySelector('select')?.focus();
    }
  });

  // ریست فرم
  document.getElementById('resetFormBtn')?.addEventListener('click', () => {
    form.reset();
    dynamicStepsContainer.innerHTML = '';
    const step7 = document.getElementById('step-7'); if (step7) step7.style.display = 'none';
    const layer1 = document.getElementById('layer_1'); if (layer1) layer1.value = '';
    submitButton && (submitButton.style.display = 'none');
    Object.keys(selections).forEach(k => delete selections[k]);
    updateLivePreview();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
});

})();
