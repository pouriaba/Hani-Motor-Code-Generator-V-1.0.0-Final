// static/js/index.js — نسخه نهایی با گارد بوت‌استرپ
if (!window.__CODING_V2_BOOTSTRAPPED__) {
window.__CODING_V2_BOOTSTRAPPED__ = true;

document.addEventListener('DOMContentLoaded', () => {
  const pageRoot = document.querySelector('.coding-page-v2');
  if (!pageRoot) return; // فقط روی همین صفحه اجرا شود

  const form                  = document.getElementById('coding-form');
  const dynamicStepsContainer = document.getElementById('dynamic-steps');
  const submitButton          = document.getElementById('submit-btn-tour');
  const liveCodeSpan          = document.getElementById('live-code');
  const liveDescriptionSpan   = document.getElementById('live-description');
  const sideStepsList         = document.getElementById('sideStepsList');

  const userRole = (document.body.dataset.role || 'guest').toLowerCase();

  const selections = {}; // ۱..۶
  // ==== Feature flags ====
  const ENABLE_INLINE_PARAM_ADD = false; // افزودن پارامتر داخل فرم ساخت (خاموش)

  function getLayerName(level) {
    const map = {1:'کلاس',2:'گروه',3:'زیرگروه',4:'مدل',5:'ویژگی فنی',6:'ویژگی ظاهری',7:'شرح نهایی'};
    return map[level] || `لایه ${level}`;
  }

  function clearDownstream(fromLevel) {
    for (let L = fromLevel + 1; L <= 6; L++) {
      delete selections[L];
      const old = document.getElementById(`step-${L}`);
      if (old) old.remove();
    }
    const step7 = document.getElementById('step-7');
    if (step7) step7.style.display = 'none';

    submitButton.disabled = true;
    submitButton.title = 'لطفاً ابتدا مراحل را تکمیل کنید.';
    updateLivePreview();

    const maxDone = Object.keys(selections)
      .map(Number)
      .filter((k) => !!selections[k]?.id)
      .reduce((a, b) => Math.max(a, b), 0);
    updateSideStepper(maxDone);
  }

  function updateLivePreview() {
    const codeParts = [];
    const descParts = [];
    for (let i = 1; i <= 6; i++) {
      if (selections[i]?.id) {
        codeParts.push(selections[i].code || '');
        descParts.push(selections[i].description || '');
      }
    }
    const l7 = document.getElementById('layer_7_text');
    const tail = (l7?.value || '').trim();
    if (tail) descParts.push(tail);

    const codeStr = codeParts.join('-').replace(/--+/g, '-').replace(/^-|-$/g, '');
    liveCodeSpan.textContent = codeStr || '';
    liveDescriptionSpan.textContent = descParts.join(' / ');
  }

  function updateSideStepper(maxDoneLevel) {
    if (!sideStepsList) return;
    sideStepsList.querySelectorAll('.s-step').forEach((stepEl) => {
      stepEl.classList.remove('is-active', 'is-done');
      const step = Number(stepEl.dataset.step);
      const descEl = stepEl.querySelector('.s-step-desc');

      if (step <= maxDoneLevel) {
        stepEl.classList.add('is-done');
        if (step <= 6) {
          const s = selections[step];
          descEl.textContent = s?.description || 'تکمیل شده';
        } else {
          descEl.textContent = 'شرح نهایی ثبت شد';
        }
      } else if (step === maxDoneLevel + 1) {
        stepEl.classList.add('is-active');
        descEl.textContent = 'در حال انتخاب...';
      } else {
        descEl.textContent = 'انتخاب نشده';
      }
    });
  }

  async function createNextStep(level, parentId) {
    try {
      const resp = await fetch(`/api/get_children/${parentId}`, { headers: { Accept: 'application/json' } });
      if (!resp.ok) throw new Error('خطا در دریافت آیتم‌ها');
      const items = (await resp.json()) || [];
      if (!Array.isArray(items) || items.length === 0) return;

      const stepDiv = document.createElement('div');
      stepDiv.className = 'form-step';
      stepDiv.id = `step-${level}`;
      stepDiv.dataset.step = String(level);

      const label = document.createElement('label');
      label.setAttribute('for', `layer_${level}`);
      label.textContent = `لایه ${level}: ${getLayerName(level)}`;

      const group = document.createElement('div');
      group.className = 'input-group';

      const sel = document.createElement('select');
      sel.name = `layer_${level}`;
      sel.id = `layer_${level}`;
      sel.dataset.level = level;
      sel.required = true;
      sel.className = 'layer-select';
      sel.add(new Option(`یک ${getLayerName(level)} انتخاب کنید...`, ''));
      items.forEach((it) => sel.add(new Option(`${it.description} (${it.code})`, it.id)));

      group.appendChild(sel);

      if (ENABLE_INLINE_PARAM_ADD && userRole === 'admin') {
        const addBtn = document.createElement('button');
        addBtn.type = 'button';
        addBtn.className = 'btn btn-add';
        addBtn.dataset.level = String(level);
        addBtn.dataset.parentId = String(parentId);
        addBtn.innerHTML = `<span>${getLayerName(level)} جدید</span>`;
        group.appendChild(addBtn);
      }

      stepDiv.appendChild(label);
      stepDiv.appendChild(group);
      dynamicStepsContainer.appendChild(stepDiv);

      document.dispatchEvent(new CustomEvent('stepRendered', { detail: { elementId: stepDiv.id } }));
    } catch (err) {
      console.error('createNextStep failed', err);
      Swal?.fire('خطا', 'دریافت آیتم‌ها انجام نشد.', 'error');
    }
  }

  document.addEventListener('change', async (e) => {
    const select = e.target.closest('select.layer-select');
    if (!select) return;

    const level = Number(select.dataset.level);
    const selectedId = select.value;

    let code = '', description = '';
    if (selectedId){
      const opt = select.options[select.selectedIndex];
      const m   = opt.text.match(/\(([^)]+)\)\s*$/); // <— ریجکس جدید: کدهای حروفی-عددی هم پشتیبانی می‌شود
      code = m?.[1] || '';
      description = (m ? opt.text.slice(0, m.index) : opt.text).trim();
    }
    selections[level] = { id: selectedId, code, description };

    clearDownstream(level - 1);

    if (!selectedId) { updateLivePreview(); return; }

    updateSideStepper(level);

    if (level < 6) {
      await createNextStep(level + 1, selectedId);
      updateSideStepper(level);
    } else {
      const step7 = document.getElementById('step-7');
      if (step7) step7.style.display = '';
    }

    const l7 = document.getElementById('layer_7_text');
    const ready = [1,2,3,4,5,6].every((i) => !!selections[i]?.id) && !!l7?.value.trim();
    submitButton.disabled = !ready;
    submitButton.title = ready ? 'آماده تولید کد' : 'لطفاً ابتدا مراحل را تکمیل کنید.';

    updateLivePreview();
  });

  form.addEventListener('input', (e) => {
    if (e.target.id === 'layer_7_text') {
      const ready = [1,2,3,4,5,6].every((i) => !!selections[i]?.id) && !!e.target.value.trim();
      submitButton.disabled = !ready;
      submitButton.title = ready ? 'آماده تولید کد' : 'لطفاً ابتدا مراحل را تکمیل کنید.';
      updateLivePreview();
    }
  });

  document.addEventListener('click', async (e) => {
    if (!ENABLE_INLINE_PARAM_ADD) return;   // ← این خط حتماً باشد
    const btn = e.target.closest('.btn-add');
    if (!btn) return;
    // ...
  });

// [FIX-STRAY-BLOCK]     const level = Number(btn.dataset.level);
// [FIX-STRAY-BLOCK]     const parentId = btn.dataset.parentId ?? 'null';
// [FIX-STRAY-BLOCK] 
// [FIX-STRAY-BLOCK]     try {
// [FIX-STRAY-BLOCK]       const r = await fetch(`/api/get_suggestions/${level}/${parentId}`);
// [FIX-STRAY-BLOCK]       const suggestions = await r.json();
// [FIX-STRAY-BLOCK]       const opts = (suggestions || []).map((x) =>
// [FIX-STRAY-BLOCK]         typeof x === 'string' ? x : x.text || x.label || x.description || ''
// [FIX-STRAY-BLOCK]       );
// [FIX-STRAY-BLOCK] 
// [FIX-STRAY-BLOCK]       if (typeof window.openSelectOrInputModal !== 'function') {
// [FIX-STRAY-BLOCK]         Swal?.fire('خطای داخلی', 'تابع مودال بارگذاری نشده است.', 'error');
// [FIX-STRAY-BLOCK]         return;
// [FIX-STRAY-BLOCK]       }
// [FIX-STRAY-BLOCK] 
// [FIX-STRAY-BLOCK]       window.openSelectOrInputModal(
// [FIX-STRAY-BLOCK]         {
// [FIX-STRAY-BLOCK]           title: `افزودن ${getLayerName(level)} جدید`,
// [FIX-STRAY-BLOCK]           listLabel: 'از میان نام‌های مشابه انتخاب کنید:',
// [FIX-STRAY-BLOCK]           inputLabel: 'یا یک نام کاملاً جدید وارد کنید:',
// [FIX-STRAY-BLOCK]           options: opts,
// [FIX-STRAY-BLOCK]           placeholder: `نام ${getLayerName(level)} جدید...`,
// [FIX-STRAY-BLOCK]           confirmText: 'افزودن',
// [FIX-STRAY-BLOCK]           cancelText: 'انصراف',
// [FIX-STRAY-BLOCK]         },
// [FIX-STRAY-BLOCK]         async (finalText) => {
// [FIX-STRAY-BLOCK]           const val = (finalText || '').trim();
// [FIX-STRAY-BLOCK]           if (!val) return;
// [FIX-STRAY-BLOCK] 
// [FIX-STRAY-BLOCK]           try {
// [FIX-STRAY-BLOCK]             const parentIdValue = parentId === 'null' || parentId === null ? null : Number(parentId);
// [FIX-STRAY-BLOCK] 
// [FIX-STRAY-BLOCK]             const resp = await fetch('/api/add_item', {
// [FIX-STRAY-BLOCK]               method: 'POST',
// [FIX-STRAY-BLOCK]               headers: { 'Content-Type': 'application/json' },
// [FIX-STRAY-BLOCK]               body: JSON.stringify({
// [FIX-STRAY-BLOCK]                 layer: level,
// [FIX-STRAY-BLOCK]                 parent_id: parentIdValue,
// [FIX-STRAY-BLOCK]                 description: val,
// [FIX-STRAY-BLOCK]               }),
            });
            if (!resp.ok) throw new Error('ثبت آیتم جدید با خطا مواجه شد');
            const data = await resp.json(); // {id, code, description}

            const select = document.getElementById(`layer_${level}`);
            if (!select) return;

            const opt = new Option(
              `${data.item?.description ?? data.description} (${data.item?.code ?? data.code})`,
              data.item?.id ?? data.id,
              true,
              true
            );
            select.add(opt);
            select.dispatchEvent(new Event('change', { bubbles: true }));
          } catch (err) {
            Swal?.fire('خطا', String(err.message || err), 'error');
          }
        }
      );
    } catch (err) {
      Swal?.fire('خطا', 'دریافت پیشنهادها انجام نشد.', 'error');
    }
  });

  document.addEventListener('stepRendered', (e) => {
    const el = document.getElementById(e.detail.elementId);
    if (!el) return;
    setTimeout(() => {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      el.querySelector('select')?.focus();
    }, 40);
  });

  document.getElementById('copyLiveCode')?.addEventListener('click', () => {
    const t = liveCodeSpan?.textContent || '';
    if (!t) return;
    navigator.clipboard?.writeText(t).then(() => {
      try {
        Swal?.fire({ toast:true, position:'bottom-start', timer:1400, showConfirmButton:false, icon:'success', title:'کد کپی شد' });
      } catch (_) {}
    });
  });

  document.getElementById('resetFormBtn')?.addEventListener('click', () => {
    form.reset();
    dynamicStepsContainer.innerHTML = '';
    const step7 = document.getElementById('step-7');
    if (step7) step7.style.display = 'none';
    const layer1 = document.getElementById('layer_1');
    if (layer1) layer1.value = '';
    submitButton.disabled = true;
    submitButton.title = 'لطفاً ابتدا مراحل را تکمیل کنید.';
    Object.keys(selections).forEach((k) => delete selections[k]);
    updateSideStepper(0);
    updateLivePreview();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  updateSideStepper(0);
  updateLivePreview();
});
} // END GUARD