{% extends 'layout.html' %}
{% block title %}کدهای ثبت شده{% endblock %}
{% block content %}
<div class="table-container">
    <h2>لیست تمام کدهای ثبت شده</h2>

    {# --- NEW FILTER FORM --- #}
    <form method="get" action="{{ url_for('view_codes') }}" class="filter-form">
        <div class="form-row">
            <input type="text" name="search" placeholder="جستجو در کد یا شرح..." value="{{ filters.search or '' }}">
            <select name="class_code">
                <option value="">همه کلاس‌ها</option>
                {% for class in all_classes %}
                    <option value="{{ class.code }}" {% if filters.class_code == class.code %}selected{% endif %}>
                        {{ class.description }}
                    </option>
                {% endfor %}
            </select>
        </div>
        <div class="form-row">
            <label for="start_date">از تاریخ:</label>
            <input type="date" name="start_date" id="start_date" value="{{ filters.start_date or '' }}">
            <label for="end_date">تا تاریخ:</label>
            <input type="date" name="end_date" id="end_date" value="{{ filters.end_date or '' }}">
        </div>
        <div class="form-row">
            <button type="submit" class="btn-primary">اعمال فیلتر</button>
            <a href="{{ url_for('view_codes') }}" class="btn-secondary">حذف فیلترها</a>
        </div>
    </form>

    <table id="codesTable">
        <thead>
            <tr>
                <th>ردیف</th>
                <th>کد کامل محصول</th>
                <th>شرح کامل محصول</th>
                <th>تاریخ ثبت</th>
                <th>عملیات</th>
            </tr>
        </thead>
        <tbody>
            {% for code in codes %}
            <tr>
                <td>{{ loop.index + ( (page - 1) * 20 ) }}</td>
                <td>{{ code.full_code }}</td>
                <td>{{ code.full_description }}</td>
                <td>{{ code.created_at.split('.')[0] }}</td>
                <td class="action-cell">
                    <form class="delete-form" action="{{ url_for('delete_code', code_id=code.id) }}" method="post" onsubmit="return confirm('آیا از حذف این کد مطمئن هستید؟');">
                        <button type="submit" class="btn-delete">حذف</button>
                    </form>
                </td>
            </tr>
            {% else %}
            <tr><td colspan="5">هیچ کدی با این مشخصات یافت نشد.</td></tr>
            {% endfor %}
        </tbody>
    </table>

    <div class="pagination-container">
        <div class="pagination">
            {% if page > 1 %}
                <a href="{{ url_for('view_codes', page=page-1, **filters) }}">&laquo; قبلی</a>
            {% endif %}

            <span>صفحه {{ page }} از {{ total_pages }}</span>

            {% if page < total_pages %}
                <a href="{{ url_for('view_codes', page=page+1, **filters) }}">بعدی &raquo;</a>
            {% endif %}
        </div>
        <a href="{{ url_for('export_csv') }}" id="export-btn" class="btn-primary">دریافت خروجی (CSV)</a>
    </div>

</div>
{% endblock %}

{% block scripts %}
    {# We no longer need search.js as filtering is done in the backend #}
{% endblock %}