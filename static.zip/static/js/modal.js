/**
 * Creates and manages a dynamic modal popup. This approach ensures no conflicts
 * by building and destroying the modal elements for each use.
 */
function openModal(config, onConfirm) {
    // --- 1. Create Modal Elements ---
    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop';

    const modal = document.createElement('div');
    modal.className = 'popup-modal';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');

    const modalContent = document.createElement('div');
    modalContent.className = 'modal-content-wrapper'; // For styling
    modal.appendChild(modalContent);
    backdrop.appendChild(modal);

    // --- 2. Close Function ---
    const close = () => {
        document.body.classList.remove('modal-open');
        backdrop.remove();
        // Remove keydown listener to prevent memory leaks
        document.removeEventListener('keydown', handleKeydown);
    };

    // --- 3. Event Handlers ---
    backdrop.addEventListener('click', (e) => {
        if (e.target === backdrop) {
            close();
        }
    });

    const handleKeydown = (e) => {
        if (e.key === 'Escape') {
            close();
        }
    };
    document.addEventListener('keydown', handleKeydown);

    // --- 4. Populate Content ---
    modalContent.innerHTML = config.innerHTML;

    // --- 5. Attach Buttons Logic ---
    const saveBtn = modalContent.querySelector('.btn-save');
    const cancelBtn = modalContent.querySelector('.btn-cancel');

    if (saveBtn) {
        saveBtn.addEventListener('click', () => {
            const result = config.onSave(); // Get data from the modal before closing
            if (result.isValid) {
                onConfirm(result.value);
                close();
            }
        });
    }

    if (cancelBtn) {
        cancelBtn.addEventListener('click', close);
    }

    // --- 6. Show Modal ---
    document.body.appendChild(backdrop);
    document.body.classList.add('modal-open');

    // Focus on the first available input or select
    const focusable = modal.querySelector('input, select');
    if (focusable) {
        focusable.focus();
    }
}

/**
 * Opens a modal for selecting from a list or entering a new value.
 */
window.openSelectOrInputModal = function(cfg = {}, onConfirm) {
    const {
        title = "افزودن آیتم جدید",
        listLabel = "از میان نام‌های مشابه:",
        inputLabel = "یا یک نام جدید وارد کنید:",
        options = [],
        placeholder = "نام آیتم...",
        confirmText = "افزودن",
        cancelText = "انصراف"
    } = cfg;

    const modalConfig = {
        innerHTML: `
            <div class="modal-header">
                <h3 class="modal-title">${title}</h3>
            </div>
            <div class="modal-body">
                <label class="modal-label">${listLabel}</label>
                <select id="popup-select" class="popup-select">
                    <option value="">— انتخاب از لیست —</option>
                    ${options.map(o => `<option value="${o}">${o}</option>`).join('')}
                </select>
                <div class="modal-sep"></div>
                <label class="modal-label">${inputLabel}</label>
                <input id="popup-new" type="text" class="popup-input" placeholder="${placeholder}">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-cancel">${cancelText}</button>
                <button type="button" class="btn btn-primary btn-save">${confirmText}</button>
            </div>
        `,
        onSave: () => {
            const s = document.getElementById('popup-select');
            const i = document.getElementById('popup-new');
            const picked = (s.value || "").trim();
            const typed = (i.value || "").trim();

            if (!picked && !typed) {
                i.focus();
                return { isValid: false };
            }
            return { isValid: true, value: typed || picked };
        }
    };

    openModal(modalConfig, onConfirm);
};