/**
 * HANI Motor – Coding V2 Tour (Index Page)
 * نسخه نهایی و پایدار
 * - مرحله ۱۰ (لایه ۷) اکنون دارای گارد برای اطمینان از ورود متن است.
 * - تمام محتوای متنی اصلی حفظ شده است.
 */
(function(){
  'use strict';

  document.addEventListener('DOMContentLoaded', function(){
    const startBtn = document.getElementById('startTourBtn');
    if (!startBtn || !window.Shepherd) {
      console.warn('Tour cannot start: Shepherd library or start button not found.');
      return;
    }

    // استایل‌های راهنما (بدون تغییر)
    (function addTourStyles(){
      if (document.getElementById('tour-style-widen')) return;
      const css = `
        .shepherd-element.shepherd-custom-theme{ max-width: 720px; width: min(92vw, 720px); }
        .shepherd-element.shepherd-custom-theme.wide{ max-width: 900px; width: min(96vw, 900px); }
        .shepherd-element .tour-table{ width:100%; border-collapse:collapse; }
        .shepherd-element .tour-table th, .shepherd-element .tour-table td{ padding:.5rem .6rem; border-bottom:1px solid #eee; text-align:right; white-space:nowrap; }
        .shepherd-element .tour-scroll{ max-height:60vh; overflow:auto; }
      `;
      const style = document.createElement('style');
      style.id = 'tour-style-widen';
      style.textContent = css;
      document.head.appendChild(style);
    })();

    // --- توابع کمکی ---
    const toFa = (n) => String(n).replace(/[0-9]/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
    const stepTitle = (cur, total, text) => `مرحله ${toFa(cur)} از ${toFa(total)}: ${text}`;
    
    const waitForElement = (selector, timeout = 5000) => {
      return new Promise((resolve, reject) => {
        const el = document.querySelector(selector);
        if (el) return resolve(el);
        let timeoutId = null;
        const observer = new MutationObserver(() => {
          if (document.querySelector(selector)) {
            clearTimeout(timeoutId);
            observer.disconnect();
            resolve(document.querySelector(selector));
          }
        });
        observer.observe(document.body, { childList: true, subtree: true });
        timeoutId = setTimeout(() => {
          observer.disconnect();
          reject(new Error(`Element "${selector}" not found after ${timeout}ms`));
        }, timeout);
      });
    };

    const guardSelection = (layerNumber) => {
      const sel = document.getElementById(`layer_${layerNumber}`);
      if (!sel || !sel.value) {
        if (window.Swal) Swal.fire({ toast: true, position: 'top', timer: 2500, showConfirmButton: false, icon: 'info', title: `لطفاً ابتدا یک گزینه برای لایه ${toFa(layerNumber)} انتخاب کنید.` });
        return false;
      }
      return true;
    };

    // *** تابع جدید برای چک کردن ورودی متنی ***
    const guardTextInput = (elementId, layerNumber) => {
      const input = document.getElementById(elementId);
      if (!input || !input.value.trim()) {
        if (window.Swal) Swal.fire({ toast: true, position: 'top', timer: 2500, showConfirmButton: false, icon: 'info', title: `لطفاً ابتدا شرح کالا در لایه ${toFa(layerNumber)} را وارد کنید.` });
        return false;
      }
      return true;
    };

    // --- ساخت تور ---
    function buildTour(){
      const tour = new Shepherd.Tour({
        useModalOverlay: true,
        defaultStepOptions: {
          classes: 'shepherd-theme-arrows shepherd-custom-theme',
          scrollTo: { behavior: 'smooth', block: 'center' },
          cancelIcon: { enabled: true }
        }
      });

      const totalSteps = 11;
      
      const steps = [
        { id: 'welcome', title: stepTitle(1,totalSteps,'شروع راهنمای ساخت کد'), text: 'به راهنمای کدینگ هانی موتور خوش آمدید. در این بخش با ساختار کدینگ آشنا می‌شوید و یاد می‌گیرید چگونه یک کد یکتا برای کالا تولید کنید.', buttons: [{ text: 'شروع', action: tour.next }] },
        { id: 'intro', title: stepTitle(2,totalSteps,'معرفی سیستم کدینگ (۱۵ کاراکتر / ۷ لایه)'), classes: 'wide', text: `سیستم کدینگ شرکت متشکل از <strong>۱۵ کاراکتر و ۷ لایه</strong> است. هر لایه بخشی از اطلاعات کالا را مشخص می‌کند؛ از کلاس کالا تا ویژگی‌های فنی و شرح نهایی.<br><br><strong>مثال کوتاه:</strong><br>کلاس: موتورسیکلت (44) → سرگروه: اسکوتر و شهری (1) → گروه: استریت (04) → شناسه متغیر: کاربرد ندارد (00) → مشخصه اصلی: حجم موتور 150 سی‌سی (002) → مشخصه فرعی: رنگ مشکی (02) → شرح نهایی: «موتورسیکلت 150 سی‌سی بنزینی مشکی»<br><br><div class="tour-scroll"><table class="tour-table"><tr><th>لایه</th><th>طول</th><th>عنوان</th><th>توضیح</th><th>مثال</th></tr><tr><td>۱</td><td>۲</td><td>کلاس کالا</td><td>بالاترین سطح دسته‌بندی</td><td>44</td></tr><tr><td>۲</td><td>۱</td><td>سرگروه</td><td>زیرمجموعهٔ اصلی کلاس</td><td>1</td></tr><tr><td>۳</td><td>۲</td><td>گروه</td><td>جزئیات دقیق‌تر از سرگروه</td><td>04</td></tr><tr><td>۴</td><td>۲</td><td>شناسه متغیر</td><td>وابسته به کلاس (کانال تامین/وضعیت دارایی/پیش‌فرض)</td><td>00</td></tr><tr><td>۵</td><td>۳</td><td>مشخصه اصلی فنی</td><td>کلیدی‌ترین ویژگی فنی</td><td>002</td></tr><tr><td>۶</td><td>۲</td><td>مشخصه فنی فرعی</td><td>جزئیات فنی تکمیلی (در صورت نیاز)</td><td>02</td></tr><tr><td>۷</td><td>۳</td><td>شرح کالا</td><td>توضیح تکمیلی (۳ کاراکتر)</td><td>—</td></tr></table></div>`, buttons: [{ classes:'shepherd-button-secondary', text:'قبلی', action: tour.back }, { text:'بعدی', action: tour.next }] },
        { id: 'side-steps', title: stepTitle(3,totalSteps,'استپر کناری و وضعیت‌ها'), attachTo: { element: '#codingStepperSide', on: 'right' }, text: 'این بخش وضعیت پیشرفت شما را نشان می‌دهد. با تکمیل هر لایه، رنگ آن سبز می‌شود و سیستم به‌طور خودکار به لایه بعدی هدایت می‌کند.', buttons: [{ classes:'shepherd-button-secondary', text:'قبلی', action: tour.back }, { text:'بعدی', action: tour.next }] },
        { id: 'layer1', title: stepTitle(4,totalSteps,'لایه ۱ – کلاس کالا (۲ کاراکتر)'), attachTo: { element: '#step-1', on: 'bottom' }, text: 'انتخاب کلاس کالا بالاترین سطح دسته‌بندی است و ماهیت کلی کالا را مشخص می‌کند. با انتخاب صحیح، مرحله بعد به‌صورت خودکار فعال می‌شود.', buttons: [{ classes:'shepherd-button-secondary', text:'قبلی', action: tour.back }, { text:'بعدی', action: () => { if (guardSelection(1)) tour.next(); } }] },
        { id: 'layer2', title: stepTitle(5,totalSteps,'لایه ۲ – سرگروه کالا (۱ کاراکتر)'), attachTo: { element: '#step-2', on: 'bottom' }, beforeShowPromise: () => waitForElement('#step-2'), text: 'این کاراکتر نشان‌دهندهٔ طبقه اصلی (سرگروه) هر کلاس است. برای مثال در کلاس محصول نهایی، سرگروه می‌تواند «اسکوتر و شهری»، «جاده‌ای و اسپرت» یا «دوچرخه» باشد.', buttons: [{ classes:'shepherd-button-secondary', text:'قبلی', action: tour.back }, { text:'بعدی', action: () => { if (guardSelection(2)) tour.next(); } }] },
        { id: 'layer3', title: stepTitle(6,totalSteps,'لایه ۳ – گروه کالا (۲ کاراکتر)'), attachTo: { element: '#step-3', on: 'bottom' }, beforeShowPromise: () => waitForElement('#step-3'), text: 'گروه کالا جزئیات دقیق‌تری از سرگروه را مشخص می‌کند. برای نمونه: در موتورسیکلت شهری، گروه می‌تواند «اسکوتر» یا «استریت» باشد.', buttons: [{ classes:'shepherd-button-secondary', text:'قبلی', action: tour.back }, { text:'بعدی', action: () => { if (guardSelection(3)) tour.next(); } }] },
        { id: 'layer4', title: stepTitle(7,totalSteps,'لایه ۴ – شناسه متغیر (۲ کاراکتر)'), attachTo: { element: '#step-4', on: 'bottom' }, beforeShowPromise: () => waitForElement('#step-4'), text: 'شناسه متغیر بسته به نوع کلاس معناهای متفاوتی دارد: مواد اولیه/ملزومات → کانال تأمین؛ دارایی ثابت → وضعیت دارایی؛ سایر کلاس‌ها → مقدار پیش‌فرض 00.', buttons: [{ classes:'shepherd-button-secondary', text:'قبلی', action: tour.back }, { text:'بعدی', action: () => { if (guardSelection(4)) tour.next(); } }] },
        { id: 'layer5', title: stepTitle(8,totalSteps,'لایه ۵ – مشخصه اصلی فنی (۳ کاراکتر)'), attachTo: { element: '#step-5', on: 'bottom' }, beforeShowPromise: () => waitForElement('#step-5'), text: 'کلیدی‌ترین ویژگی فنی کالا در این بخش مشخص می‌شود. مثلاً در گروه موتورسیکلت، این لایه می‌تواند «حجم انجین» باشد.', buttons: [{ classes:'shepherd-button-secondary', text:'قبلی', action: tour.back }, { text:'بعدی', action: () => { if (guardSelection(5)) tour.next(); } }] },
        { id: 'layer6', title: stepTitle(9,totalSteps,'لایه ۶ – مشخصه فنی فرعی (۲ کاراکتر)'), attachTo: { element: '#step-6', on: 'bottom' }, beforeShowPromise: () => waitForElement('#step-6'), text: 'این لایه جزئیات فنی تکمیلی را مشخص می‌کند و فقط در صورت نیاز استفاده می‌شود. در غیر این صورت مقدار پیش‌فرض 00 خواهد بود. برای مثال در موتورسیکلت می‌تواند نوع سیستم ترمز باشد.', buttons: [{ classes:'shepherd-button-secondary', text:'قبلی', action: tour.back }, { text:'بعدی', action: () => { if (guardSelection(6)) tour.next(); } }] },
        // *** مرحله ۱۰ (لایه ۷) اصلاح شد ***
        { id: 'layer7', title: stepTitle(10,totalSteps,'لایه ۷ – شرح کالا (۳ کاراکتر)'), attachTo: { element: '#step-7', on: 'bottom' }, beforeShowPromise: () => waitForElement('#step-7'), text: 'شرح نهایی باید ترکیبی ساده از همهٔ انتخاب‌های قبلی باشد و بخشی از کد ۱۵ کاراکتری را تشکیل می‌دهد. بدون تکمیل این بخش، امکان ساخت کد نهایی وجود ندارد.', buttons: [{ classes:'shepherd-button-secondary', text:'قبلی', action: tour.back }, { text:'بعدی', action: () => { if (guardTextInput('layer_7_text', 7)) tour.next(); } }] },
        {
          id: 'submit',
          title: stepTitle(11, totalSteps, 'تولید کد نهایی'),
          attachTo: { element: '#submit-btn-tour', on: 'top' },
          beforeShowPromise: () => waitForElement('#submit-btn-tour:not(:disabled)'),
          text: 'با تکمیل همهٔ لایه‌ها این دکمه فعال می‌شود. با انتخاب آن، کد تولید شده و به صفحهٔ نتیجه هدایت می‌شوید. برای ادامهٔ آموزش در صفحهٔ بعدی، از دکمه زیر استفاده کنید.',
          buttons: [
            { classes: 'shepherd-button-secondary', text: 'قبلی', action: tour.back },
            { 
              text: 'تولید کد و ادامه آموزش', 
              action: function() {
                // قبل از سابمیت، دکمه را دوباره فعال می‌کنیم تا فرم به درستی ارسال شود
                const submitButton = document.querySelector('#submit-btn-tour');
                if (submitButton) {
                  submitButton.style.pointerEvents = 'auto';
                  submitButton.style.opacity = '1';
                }
                try { localStorage.setItem('tour_continue_to_result', 'true'); } catch (e) {}
                const form = document.getElementById('coding-form');
                if (form) form.submit();
              }
            }
          ],
          // *** این بخش جدید اضافه شده است ***
          when: {
            show: () => {
              const submitButton = document.querySelector('#submit-btn-tour');
              if (submitButton) {
                submitButton.style.pointerEvents = 'none'; // جلوگیری از کلیک
                submitButton.style.opacity = '0.5';       // کم‌رنگ کردن دکمه
              }
            },
            hide: () => {
              const submitButton = document.querySelector('#submit-btn-tour');
              if (submitButton) {
                submitButton.style.pointerEvents = 'auto'; // فعال کردن مجدد کلیک
                submitButton.style.opacity = '1';          // بازگرداندن به حالت عادی
              }
            }
          }
        }
      ];
      
      tour.addSteps(steps);
      
      tour.on('cancel', () => { try { localStorage.removeItem('tour_continue_to_result'); } catch(e){} });

      return tour;
    }

    let tourInstance = null;
    function startTour(){
      if (tourInstance && tourInstance.isActive()) {
        tourInstance.cancel();
      }
      tourInstance = buildTour();
      if (tourInstance) tourInstance.start();
    }
    
    startBtn.addEventListener('click', startTour);
  });
})();