document.addEventListener('DOMContentLoaded', () => {

    // =================================================================
    // SECTION 1: MODAL LOGIC FOR IMPORT REPORT
    // =================================================================
    const importModal = document.getElementById('import-report-modal');
    const overlay = document.getElementById('import-report-overlay');
    const modalBody = document.getElementById('modal-report-body');
    const closeBtn = document.getElementById('modal-close-button');
    const okBtn = document.getElementById('modal-ok-button');
    if (okBtn) okBtn.textContent = 'بستن';
    // helper: حذف هر نوع input از پاپ‌آپ‌های بدون ورودی
    function removeSwalInputs() {
    const p = Swal.getPopup?.();
    if (p) {
        p.querySelector('.swal2-input')?.remove(); // text/number...
        p.querySelector('.swal2-file')?.remove();  // choose file
    }
    }

    // استایل برای هایلایت نتایج جستجو
    if (!document.getElementById('search-highlight-style')) {
    const st = document.createElement('style');
    st.id = 'search-highlight-style';
    st.textContent = '.match{background:#ffeb3b;padding:0 2px;border-radius:3px}';
    document.head.appendChild(st);
    }

    // اگر آیتم‌های روت pill «لایه n» ندارند، اضافه کن (برای مشکل نمایش «لایه ۱»)
    function ensureLevelPills() {
        document.querySelectorAll('li.parameter-item').forEach(li => {
            if (!li.querySelector('.level-pill')) {
            let level = Number(li.dataset.level);
            if (!level || Number.isNaN(level)) level = 1;

            const pill = document.createElement('span');
            pill.className = 'level-pill';
            pill.textContent = `لایه ${level}`;

            const desc = li.querySelector('.item-description');
            if (desc) {
                desc.insertBefore(pill, desc.firstChild);
            } else {
                const controls = li.querySelector('.item-controls');
                if (controls) controls.insertBefore(pill, controls.firstChild);
                else {
                const wrapper = li.querySelector('.item-wrapper');
                if (wrapper) wrapper.insertBefore(pill, wrapper.firstChild);
                else li.insertBefore(pill, li.firstChild);
                }
            }
            }
        });
    }

    function showModal() {
        if (overlay && importModal) {
            overlay.style.display = 'block';
            importModal.style.display = 'block';
        }
    }
    function hideModal() {
        if (overlay && importModal) {
            overlay.style.display = 'none';
            importModal.style.display = 'none';
        }
    }

    if (typeof importReportData !== 'undefined' && importReportData) {
        let reportHTML = `<p>عملیات با موفقیت انجام شد. <strong>${importReportData.added_count}</strong> پارامتر جدید به سیستم اضافه شد.</p>`;
        if (Object.keys(importReportData.additions_summary).length > 0) {
            reportHTML += '<hr><h4>موارد جدید اضافه شده:</h4>';
            let classDetailsHTML = '';
            for (const [className, subAdditions] of Object.entries(importReportData.additions_summary)) {
                let subDetailsHTML = '';
                for (const [parent, count] of Object.entries(subAdditions)) {
                    subDetailsHTML += `<li>${count} مورد به «${parent}»</li>`;
                }
                classDetailsHTML += `<li><b>در کلاس «${className}»:</b><ul>${subDetailsHTML}</ul></li>`;
            }
            reportHTML += `<ul>${classDetailsHTML}</ul>`;
        }
        if (importReportData.skipped_count > 0) {
            reportHTML += '<hr><h4>موارد تکراری (نادیده گرفته شدند):</h4>';
            let skippedDetailsHTML = '';
            importReportData.skipped_items.forEach(item => {
                skippedDetailsHTML += `<li>${item} از قبل وجود داشت.</li>`;
            });
            reportHTML += `<ul>${skippedDetailsHTML}</ul>`;
        }
        if (modalBody) { modalBody.innerHTML = reportHTML; }
        showModal();
    }

    if (closeBtn) closeBtn.addEventListener('click', hideModal);
    if (okBtn) okBtn.addEventListener('click', hideModal);
    if (overlay) overlay.addEventListener('click', hideModal);

    // =================================================================
    // SECTION 2: TREE, SEARCH, AND ACTION LOGIC
    // =================================================================

    function getCSRFToken() {
        var t = '';
        var m = document.querySelector('meta[name="csrf-token"]');
        if (m && m.content) t = m.content;
        var ih = document.querySelector('input[name="csrf_token"]');
        if (!t && ih && ih.value) t = ih.value;
        return t;
    }
    
    function createItemHTML(item, searchTerm = '') {
        const isArchivedClass = item.is_archived ? 'archived-item' : '';
        const toggleButton = item.has_children ?
            `<span class="toggle-btn collapsed" data-id="${item.id}"></span>` :
            `<span class="toggle-placeholder"></span>`;

        let buttons = '';
        if (!item.is_archived) {
            buttons += `<button type="button" class="btn btn-edit js-edit-param" data-id="${item.id}" data-description="${item.description}">ویرایش</button>`;
            if (item.layer_level < 7) {
                buttons += `<button type="button" class="btn btn-add-child js-add-child" data-parent-id="${item.id}" data-child-level="${item.layer_level + 1}">افزودن زیرمجموعه</button>`;
            }
        }

        // FIX: The form now has a class for easier targeting, and onsubmit is removed.
        const archiveForm = `
            <form class="js-archive-form" action="/toggle_archive_parameter/${item.id}/${item.is_archived}" method="post">
                <input type="hidden" name="csrf_token" value="${getCSRFToken()}">
                <button type="submit" class="btn ${item.is_archived ? 'btn-unarchive' : 'btn-archive'}">
                    ${item.is_archived ? 'بازیابی' : 'آرشیو'}
                </button>
            </form>`;

        // FIX: Highlight search term if it exists
        let descriptionHTML = item.description;
        if (searchTerm) {
            const regex = new RegExp(searchTerm.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'), 'gi');
            descriptionHTML = descriptionHTML.replace(regex, '<span class="match">$&</span>');
        }

        return `
            <li class="parameter-item ${isArchivedClass}" data-id="${item.id}" data-level="${item.layer_level}">
                <div class="item-wrapper">
                    ${toggleButton}
                    <div class="item-controls">
                        <span class="item-description">
                            <span class="level-pill">لایه ${item.layer_level}</span>
                            <strong class="text-primary">${item.code || ''}</strong> - ${descriptionHTML}
                        </span>
                        ${buttons}
                        ${archiveForm}
                    </div>
                </div>
            </li>`;
    }

    const searchInput = document.getElementById('paramSearchInput');
    const resetBtn = document.getElementById('resetSearchBtn');
    const treeContainer = document.getElementById('root-parameter-list');
    const searchResultsContainer = document.getElementById('search-results-container');
    let searchTimeout;

    if (searchInput) {
        searchInput.addEventListener('keyup', (e) => {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(async () => {
                const searchTerm = e.target.value.trim();
                if (searchTerm.length > 1) {
                    performSearch(searchTerm);
                } else if (!searchTerm) {
                    resetSearch();
                }
            }, 300);
        });
    }

    if (resetBtn) resetBtn.addEventListener('click', resetSearch);

    function resetSearch() {
        if (searchInput) searchInput.value = '';
        if (treeContainer) treeContainer.style.display = 'block';
        if (searchResultsContainer) {
            searchResultsContainer.innerHTML = '';
            searchResultsContainer.style.display = 'none';
        }
        if (resetBtn) resetBtn.style.display = 'none';
    }

    async function performSearch(term) {
        try {
            const response = await fetch(`/api/search_parameters?term=${encodeURIComponent(term)}`);
            if (!response.ok) { throw new Error(`Server error: ${response.status}`); }
            const items = await response.json();
            treeContainer.style.display = 'none';
            searchResultsContainer.style.display = 'block';
            resetBtn.style.display = 'inline-block';
            searchResultsContainer.innerHTML = '';
            if (items.length === 0) {
                searchResultsContainer.innerHTML = '<p style="padding: 1rem;">هیچ نتیجه‌ای یافت نشد.</p>';
                return;
            }
            const nodesById = {};
            items.forEach(node => { nodesById[node.id] = { ...node, children: [] }; });
            const searchTree = [];
            items.forEach(node => {
                if (node.parent_id && nodesById[node.parent_id]) {
                    nodesById[node.parent_id].children.push(nodesById[node.id]);
                } else {
                    searchTree.push(nodesById[node.id]);
                }
            });
            const resultList = document.createElement('ul');
            resultList.className = 'collapsible-list';
            searchTree.forEach(rootNode => renderNode(rootNode, resultList, term));
            searchResultsContainer.appendChild(resultList);
            ensureLevelPills();
        } catch (error) {
            console.error('Search failed:', error);
            searchResultsContainer.innerHTML = `<div style="padding: 1rem; color: red;"><p><strong>خطا در انجام جستجو.</strong></p><p>نام خطا: ${error.name || 'نامشخص'}</p><p>پیام خطا: ${error.message || 'نامشخص'}</p></div>`;
        }
    }

    function renderNode(node, container, term = '') {
        const liHtml = createItemHTML(node, term);
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = liHtml;
        const liElement = tempDiv.querySelector('li');
        if (liElement) {
            if (node.children && node.children.length > 0) {
                const childrenUl = document.createElement('ul');
                childrenUl.className = 'collapsible-list';
                childrenUl.style.display = 'block';
                node.children.forEach(child => renderNode(child, childrenUl, term));
                liElement.appendChild(childrenUl);
                const toggle = liElement.querySelector('.toggle-btn');
                if (toggle) {
                    toggle.textContent = '-';
                    toggle.classList.remove('collapsed');
                }
            }
            container.appendChild(liElement);
        }
    }

    async function handleEditClick(button) {
        const id = Number(button.dataset.id);
        const currentDescription = button.dataset.description || '';

        const { value: newDescription } = await Swal.fire({
            title: 'ویرایش نام پارامتر',
            input: 'text',
            inputValue: currentDescription,
            showCancelButton: true,
            confirmButtonText: 'ذخیره',
            cancelButtonText: 'انصراف',
            didOpen: () => { const p = Swal.getPopup?.(); p?.querySelector('.swal2-file')?.remove();},
            
            // FIX: Robustly remove file input
            preConfirm: (value) => {
                if (!value || !value.trim()) {
                    Swal.showValidationMessage('نام نمی‌تواند خالی باشد');
                    return false;
                }
                return value.trim();
            }
        });

        if (newDescription) {
            try {
                const res = await fetch('/api/update_item_description', {
                    method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRFToken': getCSRFToken() },
                    body: JSON.stringify({ id: id, description: newDescription })
                });
                const data = await res.json();
                if (!res.ok) throw new Error(data.message || 'خطای سرور');
                // FIX: Success modal without any input fields
                await Swal.fire({
                    title: 'موفق!',
                    text: 'پارامتر با موفقیت ویرایش شد.', // یا: 'زیرمجموعه با موفقیت اضافه شد.'
                    icon: 'success',
                    input: null,
                    didOpen: removeSwalInputs,
                    confirmButtonText: 'بستن',
                    });
                window.location.reload();
            } catch (err) {
                Swal.fire({ title: 'خطا!', text: String(err.message || err), icon: 'error', input: null, didOpen: removeSwalInputs, confirmButtonText: 'بستن' });
            }
        }
    }

    async function handleAddChildClick(button) {
        const parentId = Number(button.dataset.parentId);
        const childLevel = Number(button.dataset.childLevel);

        const { value: description } = await Swal.fire({
            title: 'افزودن زیرمجموعه',
            input: 'text',
            inputLabel: 'نام زیرمجموعه را وارد کنید',
            showCancelButton: true,
            confirmButtonText: 'افزودن',
            cancelButtonText: 'انصراف',
            didOpen: () => { const p = Swal.getPopup?.(); p?.querySelector('.swal2-file')?.remove();},
            // FIX: Robustly remove file input
            preConfirm: (value) => {
                if (!value || !value.trim()) {
                    Swal.showValidationMessage('نام نمی‌تواند خالی باشد');
                    return false;
                }
                return value.trim();
            }
        });

        if (description) {
            try {
                const res = await fetch('/api/add_item', {
                    method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRFToken': getCSRFToken() },
                    body: JSON.stringify({ layer_level: childLevel, description: description, parent_id: parentId })
                });
                const data = await res.json();
                if (!res.ok) throw new Error(data.message || 'خطای سرور');
                // FIX: Success modal without any input fields
                await Swal.fire({ title: 'موفق!', text: 'زیرمجموعه با موفقیت اضافه شد.', icon: 'success', input: null, didOpen: removeSwalInputs, confirmButtonText: 'بستن' });
                window.location.reload();
            } catch (err) {
                Swal.fire({ title: 'خطا!', text: String(err.message || err), icon: 'error', input: null, didOpen: removeSwalInputs, confirmButtonText: 'بستن' });
            }
        }
    }
    
    document.body.addEventListener('click', async (e) => {
        const target = e.target;

        // باز/بستن و لیزی‌لود بچه‌ها
        if (target.classList.contains('toggle-btn')) {
            const parentLi    = target.closest('.parameter-item');
            const parentId    = target.dataset.id;
            const isCollapsed = target.classList.contains('collapsed');

            if (isCollapsed && parentLi.querySelectorAll('ul.collapsible-list').length === 0) {
            try {
                const response = await fetch(`/api/get_parameter_children/${parentId}`);
                const children = await response.json();
                if (children.length > 0) {
                const childrenUl = document.createElement('ul');
                childrenUl.className = 'collapsible-list';
                children.forEach(child => { childrenUl.innerHTML += createItemHTML(child); });
                parentLi.appendChild(childrenUl);
                ensureLevelPills();
                } else {
                target.className = 'toggle-placeholder';
                target.textContent = '';
                }
            } catch (error) { console.error('Failed to fetch children:', error); }
            }

            const childrenList = parentLi.querySelector('ul.collapsible-list');
            if (childrenList) { childrenList.style.display = isCollapsed ? 'block' : 'none'; }
            target.textContent = isCollapsed ? '-' : '+';
            target.classList.toggle('collapsed');
            return;
        }

        // ویرایش
        const editBtn = e.target.closest('.btn-edit');
            if (editBtn) {
            e.preventDefault();
            e.stopPropagation();
            if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
            handleEditClick(editBtn);
            return;
        }

        // افزودن زیرمجموعه
        const addBtn = e.target.closest('.btn-add-child');
            if (addBtn) {
            e.preventDefault();
            e.stopPropagation();
            if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
            handleAddChildClick(addBtn);
            return;
        }
        // --- دکمه ورود دسته‌جمعی از CSV ---
        const bulkBtn = e.target.closest('#bulk-import-btn, .bulk-import-btn');
        if (bulkBtn) {
        e.preventDefault();
        handleBulkImportClick(bulkBtn);
        return;
        }
    }, true); // Capture
    
    async function handleArchiveSubmit(form) {
        const isArchive = !!form.querySelector('.btn-archive');
        const actionTitle = isArchive ? 'آرشیو' : 'بازیابی';

        const result = await Swal.fire({
            title: `تأیید ${actionTitle}`,
            html: `با <b>${actionTitle}</b> این آیتم، تمام زیرمجموعه‌های آن نیز ${actionTitle} می‌شوند. مطمئن هستید؟`,
            icon: 'warning',
            input: null,
            showCancelButton: true,
            confirmButtonText: `بله، ${actionTitle} کن`,
            cancelButtonText: 'انصراف',
            didOpen: removeSwalInputs
        });

        if (result.isConfirmed) {
            try {
            const response = await fetch(form.action, {
                method: 'POST',
                headers: { 'X-CSRFToken': getCSRFToken() }
            });
            if (!response.ok) throw new Error('عملیات در سرور با خطا مواجه شد.');
            await Swal.fire({
                title: 'موفق!',
                text: `عملیات ${actionTitle} با موفقیت انجام شد.`,
                icon: 'success',
                input: null,
                didOpen: removeSwalInputs,
                confirmButtonText: 'بستن'
            });
            window.location.reload();
            } catch (error) {
            Swal.fire({
                title: 'خطا!',
                text: String(error.message || error),
                icon: 'error',
                input: null,
                didOpen: removeSwalInputs,
                confirmButtonText: 'بستن'
                });
            }
        }
    }

        document.body.addEventListener('submit', (e) => {
            const archiveForm = e.target.closest('.js-archive-form');
            if (archiveForm) {
                e.preventDefault();
                handleArchiveSubmit(archiveForm);
            }
        });


    async function handleBulkImportClick(btn) {
            const { value: file } = await Swal.fire({
                title: 'ورود دسته‌جمعی پارامترها',
                html: `<div class="swal-guide" style="text-align: right; direction: rtl;"><strong>راهنمای فایل CSV:</strong><ul style="list-style-position: inside;"><li>فرمت: <b>CSV</b> (UTF-8)</li><li>هر ردیف = مسیر کامل از ریشه تا برگ</li><li>به صورت <b>(شرح, کد)</b> پشت سر هم</li><li style="direction: ltr; text-align: left;">کالای بازرگانی,55,قطعات یدکی,3,...</li></ul></div>`,
                input: 'file',
                inputAttributes: { accept: '.csv' },
                showCancelButton: true,
                confirmButtonText: 'ارسال فایل',
                cancelButtonText: 'انصراف',
                didOpen: () => { Swal.getPopup().querySelector('.swal2-input')?.remove(); },
                preConfirm: (f) => {
                    if (!f) { Swal.showValidationMessage('لطفاً یک فایل انتخاب کنید.'); return false; }
                    return f;
                }
            });

            if (file) {
                const formData = new FormData();
                formData.append('csv_file', file);
                Swal.showLoading();
                try {
                    const response = await fetch('/import_parameters', {
                        method: 'POST',
                        headers: { 'X-CSRFToken': getCSRFToken() },
                        body: formData
                    });
                    if (!response.ok) throw new Error('پردازش فایل با خطا مواجه شد.');
                    window.location.reload();
                } catch (err) {
                    Swal.fire({ icon: 'error', title: 'خطا', text: String(err.message || err), input: null, didOpen: removeSwalInputs });
                }
            }
        }

    ensureLevelPills();
});