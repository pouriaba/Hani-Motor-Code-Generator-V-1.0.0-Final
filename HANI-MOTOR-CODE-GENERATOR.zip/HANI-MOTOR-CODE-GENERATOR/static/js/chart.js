// static/js/chart.js  — safe for Chart.js v2/v3/v4
(function () {
  var el = document.getElementById('classDonutChart');
  if (!el) return;
  if (typeof Chart === 'undefined') {
    console.warn('[dashboard] Chart.js not found.');
    return;
  }

  // ---- helpers
  function unescapeHtml(s){
    if(!s) return s;
    return s.replace(/&quot;|&#34;/g,'"')
            .replace(/&#39;|&apos;/g,"'")
            .replace(/&amp;/g,'&')
            .replace(/&lt;/g,'<')
            .replace(/&gt;/g,'>');
  }
  function readDatasetJson(node, name){
    try {
      var v = node.getAttribute('data-'+name);
      if (!v) return [];
      v = unescapeHtml(v);
      return JSON.parse(v);
    } catch(e){
      console.error('Failed to parse data-'+name, e);
      return [];
    }
  }
  function toNumber(x){
    if (typeof x === 'number' && Number.isFinite(x)) return x;
    var n = parseFloat(String(x).replace(/,/g,''));
    return Number.isFinite(n) ? n : NaN;
  }
  // به فارسی کردن ارقام + جداکننده اعشار/هزارگان
  function toFaDigits(s){
    var str = String(s);
    var map = {'0':'۰','1':'۱','2':'۲','3':'۳','4':'۴','5':'۵','6':'۶','7':'۷','8':'۸','9':'۹'};
    return str.replace(/[0-9]/g, d => map[d]).replace(/\./g,'٫').replace(/,/g,'٬');
  }

  // ---- data
  var rawLabels = readDatasetJson(el, 'labels') || [];
  var rawValues = readDatasetJson(el, 'values') || [];

  var labels = [], values = [];
  for (var i = 0; i < Math.min(rawLabels.length, rawValues.length); i++){
    var v = toNumber(rawValues[i]);
    if (!isNaN(v) && v > 0){
      labels.push(String(rawLabels[i]));
      values.push(v);
    }
  }
  if (!values.length) return;

  // destroy any previous chart instance (v2 & v3+)
  try {
    if (Chart.getChart) {
      var c = Chart.getChart(el);
      if (c) c.destroy();
    } else if (el._chartInstance) {
      el._chartInstance.destroy();
    }
  } catch(e){}

  var total = values.reduce((a,b)=>a+b,0);
  var colors = ['#2563eb','#f97316','#059669','#8b5cf6','#db2777','#4f46e5','#10b981','#f59e0b','#ef4444'];
  var bg = colors.slice(0, values.length);

  // center text plugin (Persian digits)
  var centerText = {
    id: 'centerText',
    beforeDraw(chart){
      var area = chart.chartArea; if(!area) return;
      var ctx = chart.ctx;
      var cx = (area.left + area.right)/2;
      var cy = (area.top + area.bottom)/2;

      ctx.save();
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      ctx.font = '600 14px "IRANSans","Tahoma",sans-serif';
      ctx.fillStyle = '#6b7280';
      ctx.fillText('مجموع کل', cx, cy - 12);

      ctx.font = '800 28px "IRANSans","Tahoma",sans-serif';
      ctx.fillStyle = '#111827';
      ctx.fillText(toFaDigits(total) + ' کد', cx, cy + 18);
      ctx.restore();
    }
  };

  // detect Chart.js major
  var major = 2; try { major = parseInt((Chart.version||'2').split('.')[0],10)||2; } catch(e){}

  var config = {
    type: 'doughnut',
    data: {
      labels: labels,
      datasets: [{
        data: values,
        backgroundColor: bg,
        borderColor: '#fff',
        borderWidth: 3,
        hoverBorderWidth: 4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 400 },
      hover: { mode: 'dataset', intersect: true }
    },
    plugins: [centerText]
  };

  if (major >= 3){
    // v3/v4
    config.options.cutout = '75%';
    config.options.plugins = config.options.plugins || {};
    config.options.plugins.legend  = { display: false };   // ← لگند داخلی خاموش
    config.options.plugins.tooltip = {
      enabled: true,
      callbacks: {
        label: function(ctx){
          var v = ctx.parsed;
          return ctx.label + ': ' + toFaDigits(v) + ' کد';
        }
      }
    };
  } else {
    // v2.x
    config.options.cutoutPercentage = 75;
    config.options.legend   = { display: false };          // ← لگند داخلی خاموش
    config.options.tooltips = {
      enabled: true,
      callbacks: {
        label: function(item, data){
          var v = data.datasets[item.datasetIndex].data[item.index];
          return data.labels[item.index] + ': ' + toFaDigits(v) + ' کد';
        }
      }
    };
  }

  var chart = new Chart(el.getContext('2d'), config);
  el._chartInstance = chart;

  // custom legend (bottom)
  var legendHost = document.getElementById('pieLegend');
  if (legendHost){
    var html = '';
    for (var i=0; i<labels.length; i++){
      var pct = total > 0 ? ((values[i]/total)*100).toFixed(1) : 0;
      html += '<span class="item">'
           +    '<span class="dot" style="background:'+(bg[i]||'#ddd')+'"></span>'
           +    labels[i]
           +    '<span class="legend-percentage">'+ toFaDigits(pct) +'%</span>'
           +  '</span>';
    }
    legendHost.innerHTML = html;
  }
})();
