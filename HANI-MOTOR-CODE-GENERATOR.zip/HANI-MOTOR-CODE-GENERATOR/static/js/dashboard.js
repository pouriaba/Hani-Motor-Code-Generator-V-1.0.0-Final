
// Dashboard-only script (Chart.js HTML legend + height control)
(function(){
  const ctx = document.getElementById('usersPie');
  if(!ctx || typeof Chart === 'undefined') return;

  const datasetColors = ['#f472b6','#93c5fd','#facc15','#34d399','#a78bfa','#60a5fa'];

  // If data globals exist, use them; otherwise leave chart alone.
  const labels = (window.pieLabels || []);
  const values = (window.pieValues || []);

  // If a chart already exists on that canvas, destroy before re-create
  if (ctx._chartInstance) {
    ctx._chartInstance.destroy();
  }

  const chart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: labels,
      datasets: [{
        data: values,
        backgroundColor: datasetColors.slice(0, values.length)
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '60%',
      plugins: { legend: { display: false } }
    },
    plugins: [{
      id: 'htmlLegend',
      afterUpdate(chart) {
        const legend = document.getElementById('pieLegend');
        if(!legend) return;
        const colors = chart.data.datasets[0].backgroundColor;
        legend.innerHTML = chart.data.labels.map((l,i)=>
          `<span class="item"><span class="dot" style="background:${colors[i]}"></span>${l}</span>`
        ).join('');
      }
    }]
  });

  ctx._chartInstance = chart;
})();
