document.addEventListener('DOMContentLoaded', () => {

    // =================================================================
    // SECTION 1: MODAL LOGIC FOR IMPORT REPORT
    // =================================================================
    const importModal = document.getElementById('import-report-modal');
    const overlay = document.getElementById('import-report-overlay');
    const modalBody = document.getElementById('modal-report-body');
    const closeBtn = document.getElementById('modal-close-button');
    const okBtn = document.getElementById('modal-ok-button');

    function showModal() {
        if (overlay && importModal) {
            overlay.style.display = 'block';
            importModal.style.display = 'block';
        }
    }
    function hideModal() {
        if (overlay && importModal) {
            overlay.style.display = 'none';
            importModal.style.display = 'none';
        }
    }

    if (typeof importReportData !== 'undefined' && importReportData) {
        let reportHTML = `<p>عملیات با موفقیت انجام شد. <strong>${importReportData.added_count}</strong> پارامتر جدید به سیستم اضافه شد.</p>`;
        if (Object.keys(importReportData.additions_summary).length > 0) {
            reportHTML += '<hr><h4>موارد جدید اضافه شده:</h4>';
            let classDetailsHTML = '';
            for (const [className, subAdditions] of Object.entries(importReportData.additions_summary)) {
                let subDetailsHTML = '';
                for (const [parent, count] of Object.entries(subAdditions)) {
                    subDetailsHTML += `<li>${count} مورد به «${parent}»</li>`;
                }
                classDetailsHTML += `<li><b>در کلاس «${className}»:</b><ul>${subDetailsHTML}</ul></li>`;
            }
            reportHTML += `<ul>${classDetailsHTML}</ul>`;
        }
        if (importReportData.skipped_count > 0) {
            reportHTML += '<hr><h4>موارد تکراری (نادیده گرفته شدند):</h4>';
            let skippedDetailsHTML = '';
            importReportData.skipped_items.forEach(item => {
                skippedDetailsHTML += `<li>${item} از قبل وجود داشت.</li>`;
            });
            reportHTML += `<ul>${skippedDetailsHTML}</ul>`;
        }
        if (modalBody) { modalBody.innerHTML = reportHTML; }
        showModal();
    }

    if (closeBtn) closeBtn.addEventListener('click', hideModal);
    if (okBtn) okBtn.addEventListener('click', hideModal);
    if (overlay) overlay.addEventListener('click', hideModal);


    // =================================================================
    // SECTION 2: TREE, SEARCH, AND ACTION LOGIC
    // =================================================================

    function createItemHTML(item) {
      const isArchivedClass = item.is_archived ? 'archived-item' : '';
      const toggleButton = item.has_children
        ? `<span class="toggle-btn collapsed" data-id="${item.id}">+</span>`
        : `<span class="toggle-placeholder"></span>`;

      let buttons = '';
      if (!item.is_archived) {
        buttons += `<button class="btn btn-edit" data-id="${item.id}" data-description="${item.description}">ویرایش</button>`;
        if (item.layer_level < 7) {
          buttons += `<button class="btn btn-add-child" data-parent-id="${item.id}" data-child-level="${item.layer_level + 1}">افزودن زیرمجموعه</button>`;
        }
      }

      const archiveForm =
        `<form class="delete-form" action="/toggle_archive_parameter/${item.id}/${item.is_archived}" method="post" onsubmit="return confirmAction(this);">` +
        (item.is_archived
          ? '<button type="submit" class="btn btn-unarchive">بازیابی</button>'
          : '<button type="submit" class="btn btn-archive">آرشیو</button>') +
        '</form>';

      return `
        <li class="parameter-item ${isArchivedClass}"
            data-id="${item.id}"
            data-level="${item.layer_level}"
            data-code="${item.code || ''}">
          <div class="item-wrapper">
            ${toggleButton}
            <div class="item-controls">
              <span class="item-description">
                ${item.code ? `<strong class="text-primary">${item.code}</strong> - ` : ''}
                ${item.description}
              </span>
              ${buttons}
              ${archiveForm}
            </div>
          </div>
        </li>`;
    }

    const searchInput = document.getElementById('paramSearchInput');
    const resetBtn = document.getElementById('resetSearchBtn');
    const treeContainer = document.getElementById('root-parameter-list');
    const searchResultsContainer = document.getElementById('search-results-container');
    let searchTimeout;

    if (searchInput) {
        searchInput.addEventListener('keyup', (e) => {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(async () => {
                const searchTerm = e.target.value.trim();
                if (searchTerm.length > 1) {
                    performSearch(searchTerm);
                } else if (!searchTerm) {
                    resetSearch();
                }
            }, 300);
        });
    }

    if (resetBtn) resetBtn.addEventListener('click', resetSearch);

    function resetSearch() {
        if (searchInput) searchInput.value = '';
        if (treeContainer) treeContainer.style.display = 'block';
        if (searchResultsContainer) {
            searchResultsContainer.innerHTML = '';
            searchResultsContainer.style.display = 'none';
        }
        if (resetBtn) resetBtn.style.display = 'none';
    }

    async function performSearch(term) {
        try {
            const response = await fetch(`/api/search_parameters?term=${encodeURIComponent(term)}`);
            if (!response.ok) { throw new Error(`Server error: ${response.status}`); }
            const items = await response.json();
            treeContainer.style.display = 'none';
            searchResultsContainer.style.display = 'block';
            resetBtn.style.display = 'inline-block';
            searchResultsContainer.innerHTML = '';
            if (items.length === 0) {
                searchResultsContainer.innerHTML = '<p style="padding: 1rem;">هیچ نتیجه‌ای یافت نشد.</p>';
                return;
            }
            const nodesById = {};
            items.forEach(node => { nodesById[node.id] = { ...node, children: [] }; });
            const searchTree = [];
            items.forEach(node => {
                if (node.parent_id && nodesById[node.parent_id]) {
                    nodesById[node.parent_id].children.push(nodesById[node.id]);
                } else {
                    searchTree.push(nodesById[node.id]);
                }
            });
            const resultList = document.createElement('ul');
            resultList.className = 'collapsible-list';
            searchTree.forEach(rootNode => renderNode(rootNode, resultList));
            searchResultsContainer.appendChild(resultList);
        } catch (error) {
            console.error('Search failed:', error);
            searchResultsContainer.innerHTML = `<div style="padding: 1rem; color: red;"><p><strong>خطا در انجام جستجو.</strong></p><p>نام خطا: ${error.name || 'نامشخص'}</p><p>پیام خطا: ${error.message || 'نامشخص'}</p></div>`;
        }
    }

    function renderNode(node, container) {
        const liHtml = createItemHTML(node);
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = liHtml;
        const liElement = tempDiv.querySelector('li');
        if (liElement) {
            if (node.children && node.children.length > 0) {
                const childrenUl = document.createElement('ul');
                childrenUl.className = 'collapsible-list';
                childrenUl.style.display = 'block';
                node.children.forEach(child => renderNode(child, childrenUl));
                liElement.appendChild(childrenUl);
                const toggle = liElement.querySelector('.toggle-btn');
                if (toggle) {
                    toggle.textContent = '-';
                    toggle.classList.remove('collapsed');
                }
            }
            container.appendChild(liElement);
        }
    }

    async function handleEditClick(button) {
        const id = button.dataset.id;
        const currentDescription = button.dataset.description;
        const newDescription = prompt('لطفاً نام جدید پارامتر را وارد کنید:', currentDescription);
        if (newDescription && newDescription.trim() !== '' && newDescription.trim() !== currentDescription) {
            try {
                const response = await fetch('/api/update_item_description', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id: id, description: newDescription.trim() })
                });
                const result = await response.json();
                if (result.success) {
                    alert('پارامتر با موفقیت ویرایش شد. صفحه مجددا بارگذاری می‌شود.');
                    window.location.reload();
                } else {
                    alert(`خطا: ${result.message}`);
                }
            } catch (error) {
                alert('خطا در ارتباط با سرور.');
            }
        }
    }

    async function handleAddChildClick(button) {
        const parentId = button.dataset.parentId;
        const childLevel = button.dataset.childLevel;

        // The callback function defines what happens when the user clicks "Save"
        const saveCallback = (description) => {
            if (description) {
                // This is the existing logic to add the item via API
                fetch('/api/add_item', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        layer_level: parseInt(childLevel),
                        description: description,
                        parent_id: parseInt(parentId)
                    })
                })
                .then(response => response.json())
                .then(result => {
                    if (result.success) {
                        alert('زیرمجموعه جدید با موفقیت اضافه شد. صفحه مجددا بارگذاری می‌شود.');
                        window.location.reload();
                    } else {
                        alert(`خطا: ${result.message}`);
                    }
                })
                .catch(error => alert('خطا در ارتباط با سرور.'));
            }
        };

        // Call the new, global smart modal
        showSmartAddModal(childLevel, parentId, saveCallback);
    }
    
    document.body.addEventListener('click', async (e) => {
        const target = e.target;
        if (target.classList.contains('toggle-btn')) {
            const parentLi = target.closest('.parameter-item');
            const parentId = target.dataset.id;
            const isCollapsed = target.classList.contains('collapsed');
            if (isCollapsed && parentLi.querySelectorAll('ul.collapsible-list').length === 0) {
                try {
                    const response = await fetch(`/api/get_parameter_children/${parentId}`);
                    const children = await response.json();
                    if (children.length > 0) {
                        const childrenUl = document.createElement('ul');
                        childrenUl.className = 'collapsible-list';
                        children.forEach(child => { childrenUl.innerHTML += createItemHTML(child); });
                        parentLi.appendChild(childrenUl);
                    } else {
                        target.className = 'toggle-placeholder';
                        target.textContent = '';
                    }
                } catch (error) { console.error('Failed to fetch children:', error); }
            }
            const childrenList = parentLi.querySelector('ul.collapsible-list');
            if (childrenList) { childrenList.style.display = isCollapsed ? 'block' : 'none'; }
            target.textContent = isCollapsed ? '-' : '+';
            target.classList.toggle('collapsed');
        }
        if (target.classList.contains('btn-edit')) {
            e.preventDefault();
            handleEditClick(target);
        }
        if (target.classList.contains('btn-add-child')) {
            e.preventDefault();
            handleAddChildClick(target);
        }
    });
});