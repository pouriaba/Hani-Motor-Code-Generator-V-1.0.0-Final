// static/js/tour_result.js — بازنویسی کامل مطابق UI جدید (Result page)
(function(){
  if (window.__CODE_TOUR_RESULT_BOOT__) return;
  window.__CODE_TOUR_RESULT_BOOT__ = true;

  document.addEventListener('DOMContentLoaded', function(){
    const root = document.querySelector('.result-page');
    if (!root) return;

    // ادامه‌ی شماره‌گذاری از صفحه قبل فقط در صورت فلگ
    const shouldAutoStart = localStorage.getItem('tour_continue_to_result') === 'true';

    // Shepherd check
    if (!window.Shepherd || !Shepherd.Tour) {
      console.error('Shepherd library not found.');
      return;
    }

    // پهن‌تر کردن صفحه
    (function ensureWideLayout(){
      if (document.getElementById('wide-layout-style-result')) return;
      const css = `
        .result-page { max-width: 1440px; margin-inline: auto; }
        .result-page .result-card { max-width: 1440px; margin-inline: auto; }
        .result-page .grid.two-cols{ grid-template-columns: 7fr 5fr; }
      `;
      const style = document.createElement('style');
      style.id = 'wide-layout-style-result';
      style.textContent = css;
      document.head.appendChild(style);
    })();

    const toFa = (n)=> String(n).replace(/\d/g, d=>'۰۱۲۳۴۵۶۷۸۹'[+d]);

    function stepTitle(n, label){
      return `گام ${toFa(n)} — ${label}`;
    }

    function exists(sel){ return !!document.querySelector(sel); }

    const tour = new Shepherd.Tour({
      useModalOverlay: true,
      defaultStepOptions: {
        classes: 'shepherd-theme-arrows shepherd-custom-theme',
        scrollTo: true,
        cancelIcon: { enabled: true },
        when: {
          show: () => document.body.classList.add('shepherd-open'),
          destroy: () => document.body.classList.remove('shepherd-open'),
        }
      }
    });

    // پایه‌ی گام‌ها (۱۲ تا ۱۹)
    const baseSteps = [
      {
        id: 'success',
        title: stepTitle(12, 'سربرگ موفقیت'),
        text: 'فرآیند تولید کد ۱۵ کاراکتری به پایان رسیده و کد معتبر ایجاد شده است.',
        attachTo: { element: '.r-head', on: 'bottom' },
        buttons: [{ text:'بعدی', action: tour.next }]
      },
      {
        id: 'duplicate',
        title: stepTitle(13, 'بررسی کد تکراری'),
        text: 'در صورت وجود کد تکراری، هشدار قرمز نمایش داده می‌شود و دکمه ذخیره غیرفعال است.',
        attachTo: { element: '.dup-alert', on: 'bottom' },
        buttons: [
          { text:'قبلی', action: tour.back, classes:'shepherd-button-secondary'},
          { text:'بعدی', action: tour.next }
        ]
      },
      {
        id: 'codes',
        title: stepTitle(14, 'نمایش دو فرمت کد'),
        text: 'کد نهایی در دو فرمت نمایش داده می‌شود: با خط تیره (رسمی) و بدون خط تیره (سیستمی). برای هر فرمت، دکمه کپی وجود دارد.',
        attachTo: { element: '.info-card .code-line', on: 'bottom' },
        buttons: [
          { text:'قبلی', action: tour.back, classes:'shepherd-button-secondary'},
          { text:'بعدی', action: tour.next }
        ]
      },
      {
        id: 'label',
        title: stepTitle(15, 'کارت لیبل'),
        text: 'پیش‌نمایش لیبل محصول شامل متادیتا، لوگو، بارکد، QR و تاریخ است و برای چاپ استاندارد آماده شده است.',
        attachTo: { element: '#labelPrintArea', on: 'top' },
        buttons: [
          { text:'قبلی', action: tour.back, classes:'shepherd-button-secondary'},
          { text:'بعدی', action: tour.next }
        ]
      },
      {
        id: 'downloads',
        title: stepTitle(16, 'منوی دانلود'),
        text: 'تمام گزینه‌های دانلود (لیبل، بارکد و QR) برای دسترسی آسان‌تر، در این منوی آبشاری جمع‌آوری شده‌اند.',
        attachTo: { element: '#download-dropdown', on: 'top' }, // به منوی جدید اشاره می‌کند
        buttons: [
          { text:'قبلی', action: tour.back, classes:'shepherd-button-secondary'},
          { text:'بعدی', action: tour.next }
        ]
      },
      {
        id: 'print',
        title: stepTitle(17, 'چاپ لیبل'),
        text: 'با انتخاب گزینه چاپ، لیبل در قالب مخصوص چاپ نمایش داده می‌شود. برای خروج، دستور چاپ را لغو کنید.',
        attachTo: { element: '#printLabel', on: 'bottom' },
        buttons: [
          { text:'قبلی', action: tour.back, classes:'shepherd-button-secondary'},
          { text:'بعدی', action: tour.next }
        ]
      },
      {
        id: 'save',
        title: stepTitle(18, 'ذخیره در دیتابیس'),
        text: 'ثبت کد تولیدشده در پایگاه داده سیستم. در صورت تکراری بودن کد، این دکمه غیرفعال است.',
        attachTo: { element: '#save-btn', on: 'bottom' },
        buttons: [
          { text:'قبلی', action: tour.back, classes:'shepherd-button-secondary'},
          { text:'بعدی', action: tour.next }
        ]
      },
      {
        id: 'stability',
        title: stepTitle(19, 'پایداری ساخت بارکد و QR'),
        text: 'نمایش و دانلود بارکد/QR وابسته به JsBarcode و QRCode است. در صورت عدم بارگذاری صحیح، ابتدا صفحه را رفرش کرده و سپس با پشتیبانی تماس بگیرید.',
        attachTo: { element: '#labelPrintArea', on: 'top' },
        buttons: [
          { text:'قبلی', action: tour.back, classes:'shepherd-button-secondary'},
          { text:'پایان', action: tour.complete }
        ]
      }
    ];

    // فیلتر بر اساس وجود المنت‌ها (برای جلوگیری از قفل)
    const steps = baseSteps.filter(step => {
      const sel = step.attachTo?.element;
      if (!sel) return true;
      return !!document.querySelector(sel);
    });

    tour.addSteps(steps);

    // فالوآپ: اگر المنت هدف موجود نبود، به نقطه‌ی امن متصل شو
    tour.on('show', (ev) => {
      try{
        const step = ev.step;
        const attach = step?.options?.attachTo;
        const sel = attach && attach.element;
        if (sel && !document.querySelector(sel)) {
          step.updateStepOptions({ attachTo: { element: '.r-head', on: 'bottom' } });
        }
      }catch(e){}
    });

    if (shouldAutoStart) {
      tour.start();
      tour.on('complete', () => { try{ localStorage.removeItem('tour_continue_to_result'); }catch(e){} });
      tour.on('cancel',   () => { try{ localStorage.removeItem('tour_continue_to_result'); }catch(e){} });
    }
  });
})();
