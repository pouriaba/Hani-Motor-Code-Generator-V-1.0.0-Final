/* static/js/ui.js */

/* میکسین پیش‌فرض برای همسان‌سازی:
   - دکمه‌ها: همان کلاس‌های پروژه (btn-primary / btn-secondary / btn-danger)
   - خاموش کردن استایل پیش‌فرض Swal (buttonsStyling:false)
   - رفع پرش صفحه در RTL با مدیریت صحیح padding بدنه هنگام ناپدیدشدن اسکرول‌بار
*/
const HM_Swal = Swal.mixin({
  customClass: {
    confirmButton: 'btn btn-primary',
    cancelButton: 'btn btn-secondary',
    denyButton: 'btn btn-danger'
  },
  buttonsStyling: false,
  showCancelButton: true,
  cancelButtonText: 'انصراف',

  // مهم: مدیریت فاصله اسکرول‌بار را خودمان انجام می‌دهیم (برای RTL درست کار می‌کند)
  scrollbarPadding: false,

  didOpen: (popup) => {
    // تضمین RTL برای محتوای داخل پاپ‌آپ
    popup.setAttribute('dir','rtl');
  },

  willOpen: () => {
    // اختلاف عرض ویوپورت و clientWidth = عرض اسکرول‌بار
    const gap = window.innerWidth - document.documentElement.clientWidth;
    if (gap > 0) {
      const htmlDir = (document.documentElement.getAttribute('dir') || '').toLowerCase();
      const bodyDir = (document.body.getAttribute('dir') || '').toLowerCase();
      const isRTL = (htmlDir || bodyDir) === 'rtl';

      // در RTL اسکرول‌بار سمت چپ است؛ در LTR سمت راست
      if (isRTL) {
        document.body.style.paddingLeft = `${gap}px`;
        document.body.style.paddingRight = '';
      } else {
        document.body.style.paddingRight = `${gap}px`;
        document.body.style.paddingLeft = '';
      }
    }
  },

  didClose: () => {
    // ریست padding بدنه
    document.body.style.paddingLeft = '';
    document.body.style.paddingRight = '';
  }
});

/* هِلپر فرم مودال: ورودی‌ها را با ساختار یکسان می‌سازد */
function showFormModal({ title, html, confirmText='ذخیره', onConfirm }) {
  HM_Swal.fire({
    title: title || 'فرم',
    html,
    confirmButtonText: confirmText
  }).then(res => {
    if (res.isConfirmed && typeof onConfirm === 'function') onConfirm();
  });
}

/* Utility کوچک: حذف inputهای خودکار Swal از DOM تا با ورودی‌های ما تداخل نکنند */
function purgeExtraSwalInputs(ids = []) {
  const cont = document.querySelector('.swal2-html-container');
  if (!cont) return;
  cont.querySelectorAll('input, select, textarea').forEach(el => {
    if (!ids.includes(el.id)) el.remove();
  });
}

/* ===== Global patch: همه‌ی Swal.fire(...) ها را به HM_Swal.fire(...) وصل می‌کنیم =====
   با این کار لازم نیست تک‌تک فایل‌ها را ویرایش کنی؛ هرجایی Swal.fire صدا زده‌ای
   به‌طور خودکار از میکسین تم‌دار استفاده می‌شود.
   اگر جایی *عمداً* خواستی بدون تم باشد، از SwalFireOriginal(...) استفاده کن. */
(function(){
  if (window && window.Swal && window.HM_Swal && !window.Swal.__hmPatched) {
    // نسخه اصلی را نگه می‌داریم
    window.SwalFireOriginal = window.Swal.fire.bind(window.Swal);

    // علامت‌گذاری تا دوباره پچ نشود
    window.Swal.__hmPatched = true;

    // ریدایرکت همه فراخوانی‌ها به HM_Swal.fire با همان آرگومان‌ها
    window.Swal.fire = function () {
      return window.HM_Swal.fire.apply(window.HM_Swal, arguments);
    };
  }
})();
